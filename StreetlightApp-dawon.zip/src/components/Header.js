import { Link } from "react-router-dom";

function Header() {
  return (
    <div className="Header">
      <center>
        <button className="AP2">길찾기</button>
        
        <button className="AP1">장소 검색</button>
      </center>
    </div>
  );
}

export default Header;
