//출발지 검색창
import { Link } from "react-router-dom";

function Startgg() {
  return (
    <div className="Startgg">
        
      <center>
      <button className="Startfind">출발지 입력</button>
        
       
      </center>
      
    </div>
  );
}

export default Startgg;